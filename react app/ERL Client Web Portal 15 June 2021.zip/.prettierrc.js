module.exports = {
  printWidth: 125,
  bracketSpacing: true,
  jsxBracketSameLine: true,
  singleQuote: true,
  trailingComma: "none",
  tabWidth: 2
  // Override any other rules you want
};
