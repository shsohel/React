import React from 'react';
import { Box } from '@material-ui/core';

const SidebarContent = () => {
  return (
    <Box display="flex" flexDirection="column">
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
      <Box component="button"> Nav Link</Box>
    </Box>
  );
};

export default SidebarContent;
