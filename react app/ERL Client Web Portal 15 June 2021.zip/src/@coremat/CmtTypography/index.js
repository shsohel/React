import CmtTitle from './CmtTitle';
import CmtSubTitle from './CmtSubTitle';

export { CmtTitle, CmtSubTitle };
