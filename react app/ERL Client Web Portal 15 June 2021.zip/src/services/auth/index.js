/*import Firebase from './firebase';
import JWTAuth from './jwt';*/
import JWTAuth from './jwt';

export const AuhMethods = {
  /*firebase: Firebase,*/
  jwtAuth: JWTAuth
  // basic: BasicAuth,
};
