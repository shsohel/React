import React from 'react';
import SignUp from '../../containers/Common/authComponents/SignUp';

const Register = () => <SignUp variant="standard" wrapperVariant="bgColor" />;

export default Register;
