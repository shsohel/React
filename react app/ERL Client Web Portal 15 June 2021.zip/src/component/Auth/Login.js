import React from 'react';
import SignIn from '../../containers/Common/authComponents/SignIn';

const Login = () => <SignIn variant="standard" wrapperVariant="bgColor" />;

export default Login;
