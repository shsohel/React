import React from 'react';
import ForgotPassword from '../../containers/Common/authComponents/ForgotPassword';

const ForgotPasswordPage = () => <ForgotPassword variant="standard" wrapperVariant="bgColor" />;

export default ForgotPasswordPage;
