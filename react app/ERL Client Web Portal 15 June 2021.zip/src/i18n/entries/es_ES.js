import saMessages from '../locales/es_ES.json';

const saLang = {
  messages: {
    ...saMessages,
  },
  locale: 'es',
};
export default saLang;
