export const roleTypes = {
  SuperAdmin: 'SuperAdmin',
  Admin: 'Admin',
  ErlAdmin: 'ErlAdmin',
  Manager: 'Manager',
  User: 'User'
};
