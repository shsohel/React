export const requiredMessage = 'This field is required!';
export const emailNotValid = 'Email is not valid!';
export const passwordMisMatch = 'Password did not match!';
export const passwordRulesMisMatch = 'Password does not follow under written rules!';
export const phoneOnlyNumericals = 'Phone no. is invalid!';
export const noSpaceMessage = 'No spaces allowed';
